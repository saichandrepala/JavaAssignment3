package com.calculator.service.calculatorservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculatorserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculatorserviceApplication.class, args);
	}

}
